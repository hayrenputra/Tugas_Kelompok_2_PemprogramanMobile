import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profile_page.dart';
import 'fakultas_page.dart'; // DITAMBAHKAN

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    saveLastPage();
  }

  Future<void> saveLastPage() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lastPage', 'Dashboard');
  }

  void navigateTo(String route) {
    if (route == 'Profile') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const ProfilePage()));
    } else if (route == 'Fakultas') { // DITAMBAHKAN
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const FakultasPage()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      key: scaffoldKey,
      endDrawer: isMobile
          ? Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const DrawerHeader(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                            'assets/bg-blur.jpg'), 
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Text('myUMSIDA',
                        style: TextStyle(color: Colors.blue, fontSize: 24)),
                  ),
                  drawerItem('Dashboard', isActive: true, onTap: () {
                    Navigator.pop(context);
                  }),
                  drawerItem('Profile', isActive: false, onTap: () {
                    Navigator.pop(context);
                    navigateTo('Profile');
                  }),
                  drawerItem('Fakultas', isActive: false, onTap: () { // DITAMBAHKAN
                    Navigator.pop(context);
                    navigateTo('Fakultas');
                  }),
                  drawerItem('Visi Misi'),
                ],
              ),
            )
          : null,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/bg-dashboard.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              color: Colors.blue.shade900.withOpacity(0.85),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('myUMSIDA',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold)),
                  if (isMobile)
                    IconButton(
                      icon: const Icon(Icons.menu, color: Colors.white),
                      onPressed: () =>
                          scaffoldKey.currentState?.openEndDrawer(),
                    )
                  else
                    Row(
                      children: [
                        activeMenuItem('Dashboard'),
                        navItem('Profile', onTap: () => navigateTo('Profile')),
                        navItem('Fakultas', onTap: () => navigateTo('Fakultas')), // DITAMBAHKAN
                        navItem('Visi Misi'),
                      ],
                    ),
                ],
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(top: isMobile ? 100 : 140),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    'SELAMAT DATANG DI MY UMSIDA',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 32),
                  Text('Berita Terbaru',
                      style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 16),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        beritaBox(),
                        SizedBox(height: 12),
                        beritaBox(),
                        SizedBox(height: 12),
                        beritaBox(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget navItem(String title, {VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: InkWell(
        onTap: onTap,
        child: Text(title,
            style: const TextStyle(color: Colors.white, fontSize: 16)),
      ),
    );
  }

  Widget activeMenuItem(String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(title,
          style: TextStyle(
              color: Colors.blue.shade900, fontWeight: FontWeight.bold)),
    );
  }

  Widget drawerItem(String title,
      {bool isActive = false, VoidCallback? onTap}) {
    return ListTile(
      title: Text(
        title,
        style: TextStyle(
          color: isActive ? Colors.blue.shade900 : Colors.black,
          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      tileColor: isActive ? Colors.blue.shade100 : null,
      onTap: onTap,
    );
  }
}

class beritaBox extends StatelessWidget {
  const beritaBox({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.85),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Text(
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
        style: TextStyle(color: Colors.black),
      ),
    );
  }
}