import 'dart:html' as html;
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final nameController = TextEditingController();
  final nimController = TextEditingController();
  final fakultasController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();

  Uint8List? imageBytes;
  String activeUser = ''; 

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    
    // 1. Dapatkan username user yang sedang aktif
    activeUser = prefs.getString('activeUser') ?? '';
    final String prefix = activeUser.isEmpty ? '' : '${activeUser}_';

    // 2. Muat data profil menggunakan prefix
    nameController.text = prefs.getString('${prefix}name') ?? activeUser; 
    nimController.text = prefs.getString('${prefix}nim') ?? '';
    fakultasController.text = prefs.getString('${prefix}fakultas') ?? '';
    emailController.text = prefs.getString('${prefix}email') ?? '';
    phoneController.text = prefs.getString('${prefix}phone') ?? '';
    addressController.text = prefs.getString('${prefix}address') ?? '';

    final imageBase64 = prefs.getString('${prefix}profileImage');
    if (imageBase64 != null) {
      setState(() {
        imageBytes = base64Decode(imageBase64);
      });
    }
  }

  Future<void> saveProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final String prefix = activeUser.isEmpty ? '' : '${activeUser}_';

    // Simpan dengan prefix
    // PENTING: Semua operasi save menggunakan await
    await prefs.setString('${prefix}name', nameController.text.trim());
    await prefs.setString('${prefix}nim', nimController.text.trim());
    await prefs.setString('${prefix}fakultas', fakultasController.text.trim());
    await prefs.setString('${prefix}email', emailController.text.trim());
    await prefs.setString('${prefix}phone', phoneController.text.trim());
    await prefs.setString('${prefix}address', addressController.text.trim());

    if (imageBytes != null) {
      final imageBase64 = base64Encode(imageBytes!);
      await prefs.setString('${prefix}profileImage', imageBase64);
    }

    Navigator.pop(context);
  }

  void pickImage() {
    html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.accept = 'image/*';
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final file = uploadInput.files?.first;
      final reader = html.FileReader();

      reader.readAsArrayBuffer(file!);
      reader.onLoadEnd.listen((e) {
        setState(() {
          imageBytes = reader.result as Uint8List;
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/bg-dashboard.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              color: Colors.blue.shade900.withOpacity(0.85),
              child: const Text('myUMSIDA', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.only(top: isMobile ? 100 : 140, left: 24, right: 24, bottom: 24),
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.85),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: pickImage,
                      child: CircleAvatar(
                        radius: 60,
                        backgroundImage: imageBytes != null
                            ? MemoryImage(imageBytes!)
                            : const AssetImage('assets/default-avatar.jpg') as ImageProvider,
                        child: Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.edit, size: 20, color: Colors.blue),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    buildInput('Name', nameController),
                    buildInput('NIM', nimController),
                    buildInput('Program/Fakultas', fakultasController),
                    buildInput('Email', emailController),
                    buildInput('Phone', phoneController),
                    buildInput('Address', addressController),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: saveProfile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade900,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                      ),
                      child: const Text('Simpan'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildInput(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}