import 'package:flutter/material.dart';

class FakultasPage extends StatelessWidget {
  const FakultasPage({super.key});

  final List<String> fakultasList = const [
    'Fakultas Kedokteran Gigi',
    'Fakultas Bisnis, Hukum, dan Ilmu Sosial (FBHIS)',
    'Fakultas Agama Islam (FAI)',
    'Fakultas Ilmu Kesehatan (FIKES)',
    'Fakultas Sains dan Teknologi (FST)',
    'Fakultas Psikologi dan Ilmu Pendidikan (FPIP)',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Fakultas UMSIDA', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blue.shade900,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/bg-dashboard.jpg'), 
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: fakultasList.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.95),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.blue.shade900,
                        child: Text('${index + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                      title: Text(
                        fakultasList[index],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade800,
                        ),
                      ),
                      subtitle: const Text('Klik untuk detail program studi'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                      onTap: () {
                        // Tambahkan navigasi ke halaman detail fakultas di sini
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Menuju halaman detail ${fakultasList[index]}')),
                        );
                      },
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}