import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_page.dart';
import 'dart:convert';
import 'dart:developer'; 

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final nameController = TextEditingController();
  final passwordController = TextEditingController();
  bool showPassword = false;

  Future<void> register() async {
    final name = nameController.text.trim();
    final pass = passwordController.text.trim();

    if (name.isEmpty || pass.isEmpty) {
      showMessage('Nama dan password tidak boleh kosong');
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    
    // 1. Ambil data pengguna yang sudah ada (dalam JSON String)
    final usersJson = prefs.getString('allUsers') ?? '{}';
    Map<String, dynamic> allUsers = jsonDecode(usersJson);
    
    // Periksa apakah username sudah terdaftar
    if (allUsers.containsKey(name)) {
      showMessage('Nama pengguna sudah terdaftar. Gunakan nama lain.');
      return;
    }

    // 2. Tambahkan pengguna baru ke map
    allUsers[name] = pass; 

    // 3. Simpan map yang sudah diperbarui (di-encode kembali ke JSON String)
    // PENTING: Gunakan await di sini
    await prefs.setString('allUsers', jsonEncode(allUsers));

    // Cek di konsol (harus terlihat di sini)
    final savedUsersJson = prefs.getString('allUsers');
    log('Data akun tersimpan: $savedUsersJson');
    
    // Hapus penyimpanan lama untuk 1 user (jika ada)
    await prefs.remove('registeredName');
    await prefs.remove('registeredPassword');
    
    showMessage('Akun berhasil dibuat');
    Future.delayed(const Duration(seconds: 1), () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
    });
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: message.contains('berhasil') ? Colors.green : Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/bg-umsida.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              color: Colors.blue.shade900.withOpacity(0.8),
              child: const Text(
                'myUMSIDA',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: Container(
                width: isMobile ? double.infinity : 400,
                margin: EdgeInsets.only(top: isMobile ? 80 : 120, left: 24, right: 24),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.blue.shade900.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Text('SIGN UP', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
                    const SizedBox(height: 24),
                    buildInput('Name', nameController),
                    const SizedBox(height: 16),
                    buildPasswordInput('Password', passwordController),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: register,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white.withOpacity(0.85),
                        foregroundColor: Colors.blue.shade900,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                      ),
                      child: const Text('DAFTAR'),
                    ),
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text("Sudah punya akun? Login di sini", style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildInput(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white),
        filled: true,
        fillColor: Colors.white.withOpacity(0.2),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget buildPasswordInput(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      obscureText: !showPassword,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white),
        filled: true,
        fillColor: Colors.white.withOpacity(0.2),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        suffixIcon: IconButton(
          icon: Icon(showPassword ? Icons.visibility : Icons.visibility_off, color: Colors.white),
          onPressed: () {
            setState(() {
              showPassword = !showPassword;
            });
          },
        ),
      ),
    );
  }
}