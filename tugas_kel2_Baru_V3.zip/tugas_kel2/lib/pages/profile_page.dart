import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'edit_profile_page.dart';
import 'dashboard_page.dart';
import 'login_page.dart';
import 'fakultas_page.dart'; // DITAMBAHKAN
import 'dart:typed_data';
import 'dart:convert';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  String name = '';
  String nim = '';
  String fakultas = '';
  String email = '';
  String phone = '';
  String address = '';
  Uint8List? imageBytes;
  String activeUser = ''; 

  @override
  void initState() {
    super.initState();
    saveLastPage();
    loadProfile();
  }

  Future<void> saveLastPage() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lastPage', 'Profile');
  }

  Future<void> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    
    activeUser = prefs.getString('activeUser') ?? ''; 
    final String prefix = activeUser.isEmpty ? '' : '${activeUser}_';
    
    setState(() {
      name = prefs.getString('${prefix}name') ?? activeUser; 
      nim = prefs.getString('${prefix}nim') ?? 'NIM belum diisi';
      fakultas = prefs.getString('${prefix}fakultas') ?? 'Fakultas belum diisi';
      email = prefs.getString('${prefix}email') ?? 'Email belum diisi';
      phone = prefs.getString('${prefix}phone') ?? 'Nomor HP belum diisi';
      address = prefs.getString('${prefix}address') ?? 'Alamat belum diisi';

      final imageBase64 = prefs.getString('${prefix}profileImage');
      if (imageBase64 != null) {
        imageBytes = base64Decode(imageBase64);
      } else {
        imageBytes = null;
      }
    });
  }

  void navigateTo(String route) {
    if (route == 'Dashboard') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const DashboardPage()));
    } else if (route == 'Fakultas') { // DITAMBAHKAN
      Navigator.push(context, MaterialPageRoute(builder: (_) => const FakultasPage()));
    }
  }

  void logout() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      key: scaffoldKey,
      endDrawer: isMobile
          ? Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const DrawerHeader(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage('assets/bg-blur.jpg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Text('myUMSIDA', style: TextStyle(color: Colors.blue, fontSize: 24)),
                  ),
                  drawerItem('Dashboard', isActive: false, onTap: () {
                    Navigator.pop(context);
                    navigateTo('Dashboard');
                  }),
                  drawerItem('Profile', isActive: true, onTap: () {
                    Navigator.pop(context);
                  }),
                  drawerItem('Fakultas', isActive: false, onTap: () { // DITAMBAHKAN
                    Navigator.pop(context);
                    navigateTo('Fakultas');
                  }),
                  drawerItem('Visi Misi'),
                ],
              ),
            )
          : null,
      body: Column(
        children: [
          Stack(
            children: [
              Container(
                height: 60,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/header-bg.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                height: 60,
                color: Colors.blue.shade900.withOpacity(0.85),
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('myUMSIDA', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    if (isMobile)
                      IconButton(
                        icon: const Icon(Icons.menu, color: Colors.white),
                        onPressed: () => scaffoldKey.currentState?.openEndDrawer(),
                      )
                    else
                      Row(
                        children: [
                          navItem('Dashboard', onTap: () => navigateTo('Dashboard')),
                          activeMenuItem('Profile'),
                          navItem('Fakultas', onTap: () => navigateTo('Fakultas')), // DITAMBAHKAN
                          navItem('Visi Misi'),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: Stack(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/bg-dashboard.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Container(color: Colors.black.withOpacity(0.4)),
                Center(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: isMobile ? 40 : 80, left: 24, right: 24, bottom: 24),
                    child: Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 60,
                            backgroundImage: imageBytes != null
                                ? MemoryImage(imageBytes!)
                                : const AssetImage('assets/default-avatar.jpg') as ImageProvider,
                          ),
                          const SizedBox(height: 16),
                          Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          Text(nim),
                          const SizedBox(height: 16),
                          infoRow('Program', fakultas),
                          infoRow('Phone', phone),
                          infoRow('Email', email),
                          infoRow('Address', address),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const EditProfilePage()),
                              );
                              if (!mounted) return;
                              loadProfile(); 
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue.shade900,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                            ),
                            child: const Text('Edit Profile'),
                          ),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: logout,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red.shade700,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                            ),
                            child: const Text('Logout'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget navItem(String title, {VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: InkWell(
        onTap: onTap,
        child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16)),
      ),
    );
  }

  Widget activeMenuItem(String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(title, style: TextStyle(color: Colors.blue.shade900, fontWeight: FontWeight.bold)),
    );
  }

  Widget drawerItem(String title, {bool isActive = false, VoidCallback? onTap}) {
    return ListTile(
      title: Text(
        title,
        style: TextStyle(
          color: isActive ? Colors.blue.shade900 : Colors.black,
          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      tileColor: isActive ? Colors.blue.shade100 : null,
      onTap: onTap,
    );
  }

  Widget infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}