import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pages/login_page.dart';
import 'pages/dashboard_page.dart';
import 'pages/profile_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final lastPage = prefs.getString('lastPage');

  Widget startPage;
  if (lastPage == 'Dashboard') {
    startPage = const DashboardPage();
  } else if (lastPage == 'Profile') {
    startPage = const ProfilePage();
  } else {
    startPage = const LoginPage(); // default awal
  }

  runApp(MyApp(startPage: startPage));
}

class MyApp extends StatelessWidget {
  final Widget startPage;
  const MyApp({required this.startPage, super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: startPage,
    );
  }
}